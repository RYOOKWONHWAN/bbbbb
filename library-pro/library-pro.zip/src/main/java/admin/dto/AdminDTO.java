package admin.dto;

public class AdminDTO {
	private String admin_id;
	private String admin_password;
	private String admin_name;
	private String admin_keynum;
	public AdminDTO() {
	}
	
	

	public String getadmin_id() {
		return admin_id;
	}

	public void setadmin_id(String admin_id) {
		this.admin_id = admin_id;
	}

	public String getadmin_password() {
		return admin_password;
	}

	public void setadmin_password(String admin_password) {
		this.admin_password = admin_password;
	}

	public String getadmin_name() {
		return admin_name;
	}

	public void setadmin_name(String admin_name) {
		this.admin_name = admin_name;
	}



	public String getAdmin_keynum() {
		return admin_keynum;
	}



	public void setAdmin_keynum(String admin_keynum) {
		this.admin_keynum = admin_keynum;
	}	
	

}

