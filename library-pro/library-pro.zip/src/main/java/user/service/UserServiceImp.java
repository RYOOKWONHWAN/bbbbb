package user.service;

import user.dao.UserDAO;
import user.dto.AuthInfo;
import user.dto.UserDTO;

// 유저 관련 서비스: 회원가입,	로그인, 정보수정, 회원탈퇴. DB에 정보를 insert, select, update, delete 한다.
// AuthInfo: 회원의 정보값을 세션에 저장 하기 위해 사용.
public class UserServiceImp implements UserService {
	private UserDAO userDao;

	public UserServiceImp() {
		// TODO Auto-generated constructor stub
	}

	public void setUserDao(UserDAO userDao) {
		this.userDao = userDao;
	}

	// 유저 추가
	@Override
	public AuthInfo addUserProcess(UserDTO dto) {
		userDao.insertUser(dto);

		return new AuthInfo(dto.getUser_id(), dto.getUser_password());
	}

	// 유저 로그인
	@Override
	public UserDTO loginProcess(AuthInfo authInfo) {
		UserDTO user = userDao.selectByUserId(authInfo);
		return user;
	}

	// 회원가입시 유저 아이디 중복 체크
//   public UserDTO
	// 유저 정보 수정
	@Override
	public UserDTO updateUserProcess(String user_id) {
		// TODO Auto-generated method stub
		return null;
	}

	// 유저 수정(유저 정보를 세션에 저장하기 위해 인증 정보 형태로 리턴)
	@Override
	public AuthInfo updateUserProcess(UserDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public int idcheck(String user_id) {
		// TODO Auto-generated method stub
		System.out.println("서비스 실행됨");
		System.out.println(user_id);
		return userDao.idcheck(user_id);
	}

	@Override
	public UserDTO selectUserProcess(String id) {
		// TODO Auto-generated method stub
		return userDao.selectByUserIdString(id);
	}

	@Override
	public String getKeynum(String id) {
		// TODO Auto-generated method stub
		return userDao.getKeynum(id);
	}

	// 주소 수정
	@Override
	public AuthInfo updateAddressProcess(UserDTO dto) {
		userDao.updateAddress(dto);
		AuthInfo ati= new AuthInfo(dto.getUser_id(), dto.getUser_password());
		UserDTO user = userDao.selectByUserId(ati);
		return new AuthInfo(user.getUser_id(), user.getUser_password(), user.getUser_name());
	}

	// 비밀번호 변경
	@Override
	public AuthInfo updatePassProcess(UserDTO dto) {
		userDao.updatePass(dto);
		AuthInfo ati= new AuthInfo(dto.getUser_id(), dto.getUser_password());
		UserDTO user = userDao.selectByUserId(ati);
		return new AuthInfo(user.getUser_id(), user.getUser_password(), user.getUser_name());
	}

	// 유저 삭제
	@Override
	public void deleteUserProcess(String user_id) {
		userDao.deleteUser(user_id);
	}

}
