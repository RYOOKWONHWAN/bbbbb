package com.mycompany.myapp;
public class HomeController {
}