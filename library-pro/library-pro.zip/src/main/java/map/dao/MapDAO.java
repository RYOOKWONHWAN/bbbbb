package map.dao;

public interface MapDAO {
	public String getAddr(String user_id);
}
